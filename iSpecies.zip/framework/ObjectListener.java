
import java.util.EventListener;

interface ObjectListener extends EventListener {
	void died(ObjectEvent _e);
}

