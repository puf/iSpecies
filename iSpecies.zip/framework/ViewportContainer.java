
interface ViewportContainer {
	void terminate();
}

